#include "SAT.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>



/* use adjacent matrix to store the undirected graph */
 // AdjList elem defination
 // This is to implement qsort
int compare_integers(const void *a, const void *b) ;
/* function to read edges for current graph of size V */
void readEdges(int V, char *adj);

/* calculate the shortest path between the given two vertices
 * using bread-first search.
 * The parent array stores the parent vertex for each vertices
 * visited during BFS, so the path can be recovered. */
void BFS(int V, char *adj, int parent[], int src, int des);

/* recover path for the given destination recursively */
void recoverPath(int parent[], int des);
 
 
typedef struct Edge_node{
	int edge_value;
	struct Edge_node *next;
}E;

 // AdjList defination
typedef struct Vertex_nd{
	int Vertex_value;
	E *first;
}V, AdjList[1000];

 // struct_graph definition
typedef struct struct_graph{
	int vertices_cnt;
	int edges_cnt;
	AdjList adjlist;
}VC;

//http://www.freebsd.org/cgi/man.cgi?query=qsort&sektion=3
int compare_integers(const void *a, const void *b) 
{ 
    const int *ia = (const int *)a; // casting pointer types 
    const int *ib = (const int *)b;
    return *ia  - *ib; 
	/* integer comparison: returns negative if b > a 
	and positive if a > b */ 
} 

// Below section has been referenced from a code on github-- This was taken to help understand SAT implementation 
void compute_reduction_getvertexcover(VC *VC){
	int v=VC->vertices_cnt;
	int e=VC->edges_cnt;
	int k;// kth total
	int result;
	int result_n;
	int i,j,m,t;// print for || i for n
	E *p;
	int *c1	= (int*)malloc(v*sizeof(int));
	int c2[2];
	int c3[2];
	int *c4;

	for(k=1;k<=v;k++){
		c4 = (int*)malloc(2*k*sizeof(int));
		SAT_Manager mgr = SAT_InitManager();
		SAT_SetNumVariables(mgr, v*k);//k from 1 to n
    		
	/* initialize the value of every literal
                for(j = 0; j < k; j++){
                   for(i = 0; i < numNodes; i++){
                      x[i][j] = val++;
                   }
                }
*/

		//at least one of n is ith
		for(i=0;i<k;i++){
			for(j=1;j<=v;j++){
				c1[j-1] = ((i*v+j) << 1);
			}
			SAT_AddClause(mgr, c1, v);
		}

/*for each column, at least one of the n vertices is in VC i
                for(j = 0; j < k; j++){
                   for(i = 0; i < nodes; i++){
                      c[i] = (x[i][j] << 1);
                   }
                   SAT_AddClause(mgr, c, numNodes);
                }
*/
		
		
 /*for each row (k>1), one vertex can't be both p^{th} and q^{th} vertex in the VC*/
		for(i=0;i<k;i++){
			for(j=i+1;j<k;j++){
				for(m=1;m<=v;m++){
					c2[0] = ((i*v+m) << 1) + 1;
					c2[1] = ((j*v+m) << 1) + 1;
					SAT_AddClause(mgr, c2, 2);
				}
			}
		}

		
 /*for each column, one vertex in VC can't be both p^{th} and q^{th} vertex*/
		for(i=1;i<=v;i++){
			for(j=i+1;j<=v;j++){
				for(m=0;m<k;m++){
					c3[0] = ((m*v+i) << 1) + 1;
					c3[1] = ((m*v+j) << 1) + 1;
					SAT_AddClause(mgr, c3, 2);
				}
			}
		}

		
  
                /*for each edge, at least one endpoint is in VC*/
		for(i=0;i<v;i++){
			p=VC->adjlist[i].first;
			while(p){
				//search e
				j=p->edge_value;
				if(i<j){
					for(m=0;m<k;m++){
						c4[m] = ((m*v+i+1) << 1);
						c4[k+m] = ((m*v+j+1) << 1);
					}
					SAT_AddClause(mgr, c4, 2*k);
				}
				p=p->next;
			}
		}

		// k found
		result = SAT_Solve(mgr);
		free(c4);
		if(result == SATISFIABLE) {
			result_n = SAT_NumVariables(mgr);
			int holdingarr[result_n];
			int cnt=0;			
			for(i = 1; i <= result_n; i++) {
				int a = SAT_GetVarAsgnment(mgr, i);
				if(a == 1) {
					if(i%v==0){
						holdingarr[cnt]=(v-1);
						cnt = cnt+1;
						//printf("%d ", (v-1)); fflush(stdout);
					}else{
						holdingarr[cnt]=(i%v-1);
						cnt = cnt+1;
						//printf("%d ", (i%v-1)); fflush(stdout);
					}
				}
			}
			int arr[cnt];
			//printf("%d ", cnt); fflush(stdout);
			 for (int c = 0 ; c < cnt ; c++)
			  {
				if(cnt==0)
				{
				//printf("%s", ""); fflush(stdout);
				goto exit;
				}
				if(cnt==1 )
				{
				//printf("%d ", arr[c]); fflush(stdout);				
				goto exit;
				}	
				arr[c]=holdingarr[c];
			//printf("%d ", arr[c]); fflush(stdout);
				
			  }
			
			for (int c = 0 ; c < cnt ; c++)
			  {
			    for (int d = 0 ; d < cnt - c-1 ; d++)
			    {
			      if (arr[d] > arr[d+1]) /* For decreasing order use < */
			      {
				int swap  = arr[d];
				arr[d]   = arr[d+1];
				arr[d+1] = swap;
			      }
			    }
			  }
			//printf("\"", arr[m]);
			for(int m=0; m< cnt ;m++)
			{
			printf("%d ", arr[m]); fflush(stdout);
			}
			//printf("\" ", arr[m]);
			//printf("Before Exit");
			printf("\n");			
			exit:			
			break;
			
			
		}
	}
	free(c1);
	
}

 //Vertex Initialization
void compute_Vertexes(VC *VC,int vertices_cnt){
	int i;
	VC->vertices_cnt = vertices_cnt;
	for (i = 0; i < vertices_cnt; i++){
	  VC->adjlist[i].Vertex_value = i;
	  VC->adjlist[i].first = NULL;
	}
}


int check_edges(VC *VC,int i,int j){
	int flag=1;
	if(i>=VC->vertices_cnt || i<0){
		printf("Error:Following vertex %d doesn't exist or is not less than the vertex size",i);
		flag=0;
	}
	if(j>=VC->vertices_cnt || j<0){
		printf("Error:Following vertex %d doesn't exist or is not less than the vertex size",j);
		flag=0;
	}
	if(flag==0){
		return 0;
	}
	return 1;
}



/* Refernce taken from GitHub code snippet and modified my current code of edges to add to the strutcure containg vertex count, edge count and adjancecy list     */

void Edges_Add(VC *VC,int edge[],int edges_cnt){
	int i=1;
	int v1;
	int v2;
	E *Edge1;
	E *Edge2;
	VC->edges_cnt = edges_cnt/2;
	while(i < edges_cnt){
		v1=edge[i-1];
		v2=edge[i];
		if(v1!=v2){
			Edge2=VC->adjlist[v1].first;
			while(Edge2){
				if(v1==VC->adjlist[v1].Vertex_value && v2==Edge2->edge_value){
					break;
				}
				Edge2=Edge2->next;
			}
			if(!Edge2){
				Edge1=(E*)malloc(sizeof(E));
				Edge1->edge_value = v2;
				Edge1->next=VC->adjlist[v1].first;
				VC->adjlist[v1].first=Edge1;
				

				Edge1=(E*)malloc(sizeof(E));
				Edge1->edge_value = v1;
				Edge1->next=VC->adjlist[v2].first;
				VC->adjlist[v2].first=Edge1;
				
			}			
		}
		i=i+2;
	}
}

void Clear_graph(VC *VC){
	int i;
	E *Edge1;
	E *Edge2;
    for (i = 0; i < VC->vertices_cnt ; i++){
        Edge2 = VC->adjlist[i].first;
        while(Edge2){
            Edge1 = Edge2;
            Edge2 = Edge2->next;
			free(Edge1);
			Edge1 = NULL;
        }
        VC->adjlist[i].first = NULL;
    }
	VC->edges_cnt=0;
	VC->vertices_cnt=0;
}



int main()
{
	VC VC;
	char a[8000];
	char cmd;

	int vertices_cnt;
	
	int eline[8000];
	char *split = (char *)" E{<,>}"; /*  Refernce was taken from git but this was modified to compile with newer versions     */
	char *p;

	int i;
	int j;
	int start;
	int end;
	
	while(fgets(a,8000,stdin)){
		cmd = a[0];
		if(cmd=='V' || cmd=='v'){
			sscanf(a,"V %d",&vertices_cnt);
			Clear_graph(&VC);			
			compute_Vertexes(&VC,vertices_cnt);
		}
		else if(cmd=='E' || cmd=='e'){
			// transfer input into array
			i=0;
			j=0;
			p = strtok(a,split);
			while(p!=NULL) {
				sscanf(p,"%d",&eline[i]);
				//printf("%d ",eline[i]);
				p = strtok(NULL,split);
				i=i+1;
			}
			// check array
			for(j=0;j<i-1;j=j+2){
				if(check_edges(&VC,eline[j],eline[j+1])==0){
					break;
				}
			}
			if(j<i-1){
				Clear_graph(&VC);				
				continue;
				
			}else{
				
				Edges_Add(&VC,eline,i-1);
				compute_reduction_getvertexcover(&VC);
				fflush(stdout);
			}
			
		}
	}
	return 0;
}
